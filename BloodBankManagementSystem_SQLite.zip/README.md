
# Blood Bank Management System (SQLite Version)

## How to Run:

1. Install Flask if not installed:
   ```
   pip install flask
   ```

2. Go to project directory and run:
   ```
   python app.py
   ```

3. Open your browser and visit:
   ```
   http://localhost:5000/
   ```

## Admin Credentials:
- Username: admin
- Password: admin123
